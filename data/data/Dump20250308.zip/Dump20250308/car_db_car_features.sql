-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: car_db
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `car_features`
--

DROP TABLE IF EXISTS `car_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `car_features` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `car_id` bigint NOT NULL,
  `AC_front` tinyint(1) DEFAULT '0',
  `AC_rear` tinyint(1) DEFAULT '0',
  `backup_camera` tinyint(1) DEFAULT '0',
  `cruise_control` tinyint(1) DEFAULT '0',
  `navigation` tinyint(1) DEFAULT '0',
  `power_locks` tinyint(1) DEFAULT '0',
  `sunroof` tinyint(1) DEFAULT '0',
  `heated_seats` tinyint(1) DEFAULT '0',
  `bluetooth` tinyint(1) DEFAULT '0',
  `acfront` bit(1) NOT NULL,
  `acrear` bit(1) NOT NULL,
  `airbag_driver` bit(1) NOT NULL,
  `airbag_passenger` bit(1) NOT NULL,
  `am_fm_stereo` bit(1) NOT NULL,
  `anti_lock_brakes` bit(1) NOT NULL,
  `bucket_seats` bit(1) NOT NULL,
  `cd_player` bit(1) NOT NULL,
  `dvd_system` bit(1) NOT NULL,
  `fog_lights` bit(1) NOT NULL,
  `hands_free` bit(1) NOT NULL,
  `leather_interior` bit(1) NOT NULL,
  `memory_seats` bit(1) NOT NULL,
  `mp3player` bit(1) NOT NULL,
  `portable_audio` bit(1) NOT NULL,
  `power_seats` bit(1) NOT NULL,
  `power_windows` bit(1) NOT NULL,
  `premium_audio` bit(1) NOT NULL,
  `rear_window` bit(1) NOT NULL,
  `third_row_seats` bit(1) NOT NULL,
  `tow_package` bit(1) NOT NULL,
  `windows_defroster` bit(1) NOT NULL,
  `wiper_tinted_glass` bit(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `car_id` (`car_id`),
  CONSTRAINT `car_features_ibfk_1` FOREIGN KEY (`car_id`) REFERENCES `cars` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-08 20:46:02
